﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
using System;
using System.Threading;
using OpenQA.Selenium;
using OpenQA.Selenium.Appium;
using OpenQA.Selenium.Appium.Interfaces;
using OpenQA.Selenium.Appium.MultiTouch;
using OpenQA.Selenium.Interactions;
using OpenQA.Selenium.Remote;

namespace MobileAutomation
{
    
    [TestFixture()]
    public class MobileAppAndroid
    {
        public AppiumDriver driver;

        [TestFixtureSetUp]
        public void SetUp()
        {
            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.SetCapability("device", "Android");
           capabilities.SetCapability("deviceName", "Nexus_4V");
           //capabilities.SetCapability("deviceName", "Nexus 4");
            capabilities.SetCapability("platformName", "Android");
            capabilities.SetCapability("platformVersion", "5.1.1");
            driver = new AppiumDriver (new Uri("http://127.0.0.1:4723/wd/hub"),capabilities);
        }  

        [Test()]
        public void OpenHofHomePage()
        {
            int waittime = 1000;
            //uk.co.travelrepublic.travelrepublic:id/dialog_cancel_button
            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/search_edit_text")).SendKeys("LONDON");
            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/hotel_title")).Click();
            Thread.Sleep(waittime);
            TouchAction action = new TouchAction();
            action.MoveTo(10, 200);
            int day = DateTime.Now.AddDays(2).Day;
            driver.FindElement(ByAndroidUIAutomator.XPath("//android.widget.TextView[@text='" + day + "']")).Click();
            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.XPath("//android.widget.TextView[@text='" + (day + 2) + "']")).Click();
            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/search_floating_panel_date_close")).Click();
            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/num_children_plus")).Click();
            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/add_room")).Click();
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/add_room")).Click();

            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/search_floating_panel_people_close")).Click();

            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/search_button")).Click();

            Thread.Sleep(50000);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/hotel_price")).Click();

            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/stay_at_hotel")).Click();
            Thread.Sleep(waittime);
            driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/room_price")).Click();

            
            // Multi room condition need to be handles
            //Thread.Sleep(2000);
            //driver.FindElement(ByAndroidUIAutomator.Id("uk.co.travelrepublic.travelrepublic:id/book_now_button")).Click();
            //uk.co.travelrepublic.travelrepublic:id/sort_button
            //    android.widget.CheckedTextView
            //        Our Recommendations
            
        }

        [Test()]
        public void MenuItems ()
        {

            driver.FindElement(ByAndroidUIAutomator.Id("search_toggle")).Click();
            Thread.Sleep(2000);
            driver.FindElement(ByAndroidUIAutomator.XPath("//android.widget.TextView[@text='FLIGHTS']")).Click();

            driver.FindElement(ByAndroidUIAutomator.Id("search_toggle")).Click();
            Thread.Sleep(2000);
            driver.FindElement(ByAndroidUIAutomator.XPath("//android.widget.TextView[@text='HOLIDAYS']")).Click();
            Thread.Sleep(2000);


            driver.FindElement(ByAndroidUIAutomator.Id("search_toggle")).Click();
            Thread.Sleep(2000);
            driver.FindElement(ByAndroidUIAutomator.XPath("//android.widget.TextView[@text='HOTELS']")).Click();
        }

        [TestFixtureTearDown]
        public void End()
        {
           // driver.Dispose();
        }
    }

}
